# Laborator: functii, metode si importuri pe web
# Student: Munteanu Ion
# Grupa: SI-266

import requests
import time
import re
import hashlib
import json
import socket
import ssl
from datetime import datetime, timezone
from urllib.parse import urlparse, urljoin

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10

# Exercitiul 47
DEFAULT_HEADERS = {"User-Agent": "WebLab-Munteanu-Ion"}


# Exercitiile 21 si 23
def fetch(url: str, timeout=10):
    """Descarca pagina si returneaza raspunsul."""
    time.sleep(1)
    return requests.get(url, timeout=timeout, headers=DEFAULT_HEADERS)


# Exercitiile 22 si 26
def get_status(url: str) -> int:
    """Returneaza codul de stare al paginii."""
    return fetch(url).status_code


# Exercitiile 24 si 25
def get_title(html: str) -> str:
    """Extrage titlul dintre tagurile title."""
    start = html.lower().find("<title>")
    if start == -1:
        return "Titlu lipsa"
    start += len("<title>")
    end = html.lower().find("</title>", start)
    if end == -1:
        return "Titlu lipsa"
    return html[start:end].strip()


# Exercitiul 27
def page_exists(url: str) -> bool:
    """Verifica pagina fara sa opreasca programul la erori."""
    try:
        return fetch(url).ok
    except requests.RequestException:
        return False


# Exercitiul 28
def check_paths(base: str, paths: list) -> dict:
    """Returneaza codul HTTP pentru fiecare cale."""
    results = {}
    for path in paths:
        try:
            results[path] = get_status(urljoin(base, path))
        except requests.RequestException:
            results[path] = None  # Nu am primit un raspuns HTTP.
    return results


# Exercitiul 29
def get_header(url: str, name: str, default="lipseste") -> str:
    """Returneaza valoarea unui antet."""
    return fetch(url).headers.get(name, default)


# Exercitiul 30
def security_headers(url: str) -> dict:
    """Verifica daca exista cele cinci antete de securitate."""
    response = fetch(url)
    response.raise_for_status()
    names = ["Strict-Transport-Security", "Content-Security-Policy",
             "X-Frame-Options", "X-Content-Type-Options", "Referrer-Policy"]
    results = {}
    for name in names:
        results[name] = name in response.headers
    return results


# Exercitiul 31
def score_headers(results: dict) -> str:
    """Returneaza numarul de antete prezente din total."""
    count = 0
    for value in results.values():
        if value:
            count += 1
    return str(count) + "/" + str(len(results))


# Exercitiul 32
def fetch_robots(base: str):
    """Citeste robots.txt sau returneaza None daca nu este disponibil."""
    try:
        response = fetch(urljoin(base, "/robots.txt"))
        if response.ok:
            return response.text
    except requests.RequestException:
        pass
    return None


def disallowed_paths(robots_text) -> list:
    """Extrage valorile Disallow din robots.txt."""
    paths = []
    if robots_text is None:
        return paths
    for line in robots_text.splitlines():
        line = line.split("#", 1)[0].strip()
        name, separator, value = line.partition(":")
        if separator and name.strip().lower() == "disallow":
            value = value.strip()
            if value:
                paths.append(value)
    return paths


# Exercitiul 33
def response_times(*urls) -> dict:
    """Masoara durata fiecarei cereri, fara pauza dintre cereri."""
    results = {}
    for url in urls:
        time.sleep(1)
        start = time.perf_counter()
        try:
            requests.get(url, timeout=TIMEOUT)
            results[url] = time.perf_counter() - start
        except requests.RequestException:
            results[url] = None
    return results


# Exercitiul 34
def log(message, **details):
    """Afiseaza mesajul si detaliile primite."""
    text = message
    for name, value in details.items():
        text += " | " + name + "=" + str(value)
    print(text)


# Exercitiul 37
def extract_links(html: str) -> list:
    """Extrage legaturile fara duplicate, in ordinea din pagina."""
    links = re.findall(r'href="([^"]+)"', html)
    results = []
    for link in links:
        if link not in results:
            results.append(link)
    return results


# Exercitiul 38
def split_links(links: list, domain: str) -> tuple:
    """Separa legaturile web interne de cele externe."""
    if not domain.startswith(("https://", "http://")):
        domain = "https://" + domain
    hostname = urlparse(domain).netloc.lower()
    internal = []
    external = []
    for link in links:
        url = urljoin(domain, link)
        parsed = urlparse(url)
        # mailto si javascript nu sunt adrese de pagini web.
        if parsed.scheme not in ("http", "https"):
            continue
        if parsed.netloc.lower() == hostname:
            if url not in internal:
                internal.append(url)
        elif url not in external:
            external.append(url)
    return internal, external


# Exercitiul 40
def page_fingerprint(url: str) -> str:
    """Calculeaza amprenta SHA256 a paginii."""
    response = fetch(url)
    response.raise_for_status()
    return hashlib.sha256(response.content).hexdigest()


# Exercitiul 42
def resolve(hostname: str) -> str:
    """Returneaza o adresa IPv4 pentru domeniu."""
    return socket.gethostbyname(hostname)


# Exercitiul 43
def cert_days_left(hostname: str) -> int:
    """Returneaza numarul de zile pana la expirarea certificatului."""
    time.sleep(1)
    context = ssl.create_default_context()
    with socket.create_connection((hostname, 443), timeout=TIMEOUT) as sock:
        with context.wrap_socket(sock, server_hostname=hostname) as connection:
            certificate = connection.getpeercert()
    seconds = ssl.cert_time_to_seconds(certificate["notAfter"])
    expiry = datetime.fromtimestamp(seconds, timezone.utc)
    return (expiry - datetime.now(timezone.utc)).days


# Exercitiul 50
def site_report(url: str) -> dict:
    """Colecteaza, afiseaza si salveaza raportul site-ului."""
    hostname = urlparse(url).hostname
    report = {
        "student": "Munteanu Ion", "grupa": "SI-266",
        "url": url, "checked_at": datetime.now().isoformat(),
        "status": None, "final_url": None, "title": None,
        "ip": None, "redirects": None, "http_final_url": None,
        "security_headers": None, "security_score": None,
        "certificate_days_left": None,
        "internal_links": None, "external_links": None,
        "disallowed_paths": None, "errors": []
    }
    try:
        response = fetch(url)
        report["status"] = response.status_code
        report["final_url"] = response.url
        response.raise_for_status()
        report["title"] = get_title(response.text)
        internal, external = split_links(extract_links(response.text), response.url)
        report["internal_links"] = len(internal)
        report["external_links"] = len(external)
    except requests.RequestException as error:
        report["errors"].append("Pagina: " + str(error))

    try:
        report["ip"] = resolve(hostname)
    except OSError as error:
        report["errors"].append("DNS: " + str(error))

    try:
        http_url = urlparse(url)._replace(scheme="http").geturl()
        response = fetch(http_url)
        report["redirects"] = []
        for step in response.history:
            report["redirects"].append({"status": step.status_code,
                                        "url": step.url,
                                        "location": step.headers.get("Location")})
        report["http_final_url"] = response.url
        response.raise_for_status()
    except requests.RequestException as error:
        report["errors"].append("Redirectionari: " + str(error))

    try:
        report["security_headers"] = security_headers(url)
        report["security_score"] = score_headers(report["security_headers"])
    except requests.RequestException as error:
        report["errors"].append("Antete: " + str(error))

    try:
        report["certificate_days_left"] = cert_days_left(hostname)
    except (OSError, ValueError, KeyError) as error:
        report["errors"].append("Certificat: " + str(error))

    robots_text = fetch_robots(url)
    if robots_text is not None:
        report["disallowed_paths"] = disallowed_paths(robots_text)
    else:
        report["errors"].append("robots.txt nu este disponibil.")

    print("=== Raport site:", url, "===")
    labels = {"status": "Cod de stare", "final_url": "URL final",
              "title": "Titlu", "ip": "Adresa IP",
              "redirects": "Redirectionari", "http_final_url": "URL final HTTP",
              "security_score": "Scor securitate",
              "certificate_days_left": "Zile pana la expirarea certificatului",
              "internal_links": "Legaturi interne",
              "external_links": "Legaturi externe",
              "disallowed_paths": "Cai interzise"}
    for key, label in labels.items():
        value = report[key]
        print(label + ":", value if value is not None else "indisponibil")
    for error in report["errors"]:
        print("Observatie:", error)
    with open("report.json", "w", encoding="utf-8") as file:
        json.dump(report, file, indent=2, ensure_ascii=False)
    print("Salvat in report.json")
    return report


# Exercitiul 46: la import, __name__ este webtools, nu __main__.
# De aceea autotestul ruleaza doar cu python webtools.py.
if __name__ == "__main__":
    try:
        print("Autotest:", get_status(BASE_URL))
    except requests.RequestException as error:
        print("Nu am putut accesa site-ul:", error)
