# Laborator: functii, metode si importuri pe web
# Student: Munteanu Ion
# Grupa: SI-266

import requests
import urllib.request
import urllib.error
import time
from requests import get
import requests as rq

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10


def run():
    """Executa exercitiile 1-8."""
    print("Exercitiul 1")
    print("Versiunea requests:", requests.__version__)
    # requests este externa si se instaleaza cu pip.
    # urllib face parte din biblioteca standard Python.

    print("Exercitiul 2")
    try:
        response = requests.get(BASE_URL, timeout=TIMEOUT)
        print("import requests:", response.status_code)
        time.sleep(1)
        response = get(BASE_URL, timeout=TIMEOUT)
        print("from requests import get:", response.status_code)
    except requests.RequestException as error:
        print("Cererea nu a reusit:", error)
    # requests.get arata din ce modul vine functia.
    # Importul direct permite sa scriu mai putin la fiecare apel.

    print("Exercitiul 3")
    # Un alias scurt este util pentru nume lungi. Un alias necunoscut
    # poate face mai greu de inteles din ce modul vine functia.
    time.sleep(1)
    try:
        response = rq.get(BASE_URL, timeout=TIMEOUT)
        print(response.status_code)
    except requests.RequestException as error:
        print("Cererea nu a reusit:", error)

    print("Exercitiul 4")
    time.sleep(1)
    try:
        with urllib.request.urlopen(BASE_URL, timeout=TIMEOUT) as response:
            print("Status:", response.status)
            print(response.read().decode("utf-8", errors="replace")[:200])
    except urllib.error.HTTPError as error:
        # urllib ridica o exceptie si pentru coduri ca 403 sau 404.
        print("Status:", error.code)
        print(error.read().decode("utf-8", errors="replace")[:200])
        error.close()
    except (urllib.error.URLError, OSError) as error:
        print("Pagina nu poate fi citita:", error)

    print("Exercitiul 5")
    print(dir(requests))
    # get este functie, Session este clasa, exceptions este modul.

    print("Exercitiul 6")
    help(requests.get)
    # timeout este parametrul pentru timpul maxim de asteptare.
    # get primeste **kwargs; detaliile sunt descrise la requests.request.
    time.sleep(1)
    try:
        response = requests.get(BASE_URL, timeout=TIMEOUT)
        print(response.status_code)
    except requests.RequestException as error:
        print("Cererea nu a reusit:", error)

    print("Exercitiul 7")
    time.sleep(1)
    start = time.perf_counter()
    try:
        response = requests.get(BASE_URL, timeout=TIMEOUT)
        duration = time.perf_counter() - start
        print("Durata totala:", duration, "secunde")
        print("response.elapsed:", response.elapsed.total_seconds(), "secunde")
        # elapsed masoara pana la primirea antetelor. perf_counter
        # include si citirea corpului, deci valorile pot fi diferite.
    except requests.RequestException as error:
        print("Cererea nu a reusit:", error)

    print("Exercitiul 8")
    try:
        import bs4
        print("bs4 este instalat:", bs4.__version__)
    except ImportError:
        print("Instalati modulul cu: pip install beautifulsoup4")

    # Modulul este o unitate de cod, de obicei un fisier .py.
    # Pachetul grupeaza module. Biblioteca poate contine mai multe pachete.


if __name__ == "__main__":
    run()
