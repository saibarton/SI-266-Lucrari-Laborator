# Laborator: functii, metode si importuri pe web
# Student: Munteanu Ion
# Grupa: SI-266

import requests
from webtools import (fetch, get_status, get_title, page_exists, check_paths,
                      get_header, security_headers, score_headers, fetch_robots,
                      disallowed_paths, response_times, log)

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10

# Functiile exercitiilor 21-34 sunt in webtools.py, conform exercitiului 44.


def run_example(number, function, *args, **kwargs):
    """Ruleaza un exemplu si afiseaza erorile de retea."""
    print("Exercitiul", number)
    try:
        result = function(*args, **kwargs)
        print(result)
        return result
    except requests.RequestException as error:
        print("Cererea nu a reusit:", error)
        return None


def run():
    """Apeleaza functiile pentru exercitiile 21-34."""
    response = run_example(21, fetch, BASE_URL)
    if response is not None:
        print("Status:", response.status_code)

    for path in ["/", "/robots.txt", "/sitemap.xml"]:
        run_example(22, get_status, BASE_URL + path)
    # fetch face time.sleep(1) inainte de fiecare cerere.

    run_example(23, fetch, BASE_URL)
    run_example(23, fetch, BASE_URL, timeout=3)

    if response is not None:
        print("Exercitiul 24:", get_title(response.text))
    else:
        print("Exercitiul 24:", get_title("<title>Laborator</title>"))

    print("Exercitiul 25")
    help(get_title)

    print("Exercitiul 26")
    try:
        print(get_status(123))
    except requests.RequestException as error:
        print("URL gresit:", error)
    # Adnotarea str nu opreste apelul cu 123. requests da o eroare
    # fiindca 123 nu este un URL valid, nu fiindca am scris str.

    print("Exercitiul 27:", page_exists("https://this-domain-does-not-exist.invalid"))
    run_example(28, check_paths, BASE_URL, ["/", "/robots.txt", "/sitemap.xml"])
    run_example(29, get_header, BASE_URL, name="Server")
    run_example(30, security_headers, BASE_URL)
    print("Exercitiul 31")
    try:
        print(score_headers(security_headers(BASE_URL)))
    except requests.RequestException as error:
        print("Nu pot calcula scorul:", error)

    print("Exercitiul 32")
    robots = fetch_robots(BASE_URL)
    print(disallowed_paths(robots))
    print("Test cu None:", disallowed_paths(None))
    run_example(33, response_times, BASE_URL, BASE_URL + "/robots.txt")
    print("Exercitiul 34")
    log("verificat", url=BASE_URL, status=response.status_code if response is not None else None)

    # print doar afiseaza. return da valoarea inapoi, ca sa o pot
    # salva intr-o variabila sau folosi in alta functie.


if __name__ == "__main__":
    run()
