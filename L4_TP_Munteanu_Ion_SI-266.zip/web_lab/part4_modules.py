# Laborator: functii, metode si importuri pe web
# Student: Munteanu Ion
# Grupa: SI-266

import json
import socket
import requests
from urllib.parse import urlparse, urljoin
from html.parser import HTMLParser
from webtools import (fetch, extract_links, split_links, page_fingerprint,
                      resolve, cert_days_left)

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10


# Exercitiul 35
def parse_url(url):
    """Afiseaza componentele URL-ului."""
    parsed = urlparse(url)
    print("Protocol:", parsed.scheme)
    print("Domeniu:", parsed.netloc)
    print("Cale:", parsed.path)
    print("Parametri:", parsed.query)
    print("Fragment:", parsed.fragment)


# Exercitiul 36
def complete_urls(base, links):
    """Transforma adresele relative in adrese complete."""
    for link in links:
        print(urljoin(base, link))


# Exercitiul 39
class ImageFinder(HTMLParser):
    """Retine sursele imaginilor din HTML."""

    def __init__(self):
        """Pregateste parserul si lista imaginilor."""
        super().__init__()
        self.images = []

    def handle_starttag(self, tag, attrs):
        """Adauga atributul src pentru fiecare tag img."""
        if tag == "img":
            src = dict(attrs).get("src")
            if src is not None:
                self.images.append(src)


def find_images(html):
    """Afiseaza imaginile si compara numarul cu tagurile img."""
    finder = ImageFinder()
    finder.feed(html)
    print(len(finder.images), "imagini gasite")
    for src in finder.images:
        print(src)
    print("Numar de taguri <img:", html.lower().count("<img"))


def test_images():
    """Verifica parserul pe un fragment cu rezultat cunoscut."""
    test_html = '''
    <html><body>
      <img src="/logo.png" alt="Logo">
      <IMG SRC="poza.jpg">
      <img alt="imagine fara src">
      <img src="https://cdn.example.com/banner.webp" />
      <a href="/despre">Aceasta nu este o imagine</a>
    </body></html>
    '''
    finder = ImageFinder()
    finder.feed(test_html)
    print(finder.images)
    assert finder.images == ["/logo.png", "poza.jpg",
                              "https://cdn.example.com/banner.webp"], \
        "Parserul nu a gasit exact imaginile asteptate"
    print("Testul a trecut!")
    # feed() citeste HTML-ul si apeleaza singur handle_starttag().
    # In browser se poate compara lista cu sursa deschisa prin Ctrl+U.


# Exercitiul 41
def save_headers(url):
    """Salveaza antetele in JSON si le citeste inapoi."""
    response = fetch(url)
    with open("headers.json", "w", encoding="utf-8") as file:
        json.dump(dict(response.headers), file, indent=2)
    with open("headers.json", "r", encoding="utf-8") as file:
        headers = json.load(file)
    print("Antet citit:", headers.get("Content-Type", "lipseste"))
    print("Statusul raspunsului:", response.status_code)


def run():
    """Executa exercitiile 35-43."""
    print("Exercitiul 35")
    parse_url("https://cybercor.org/path?x=1#top")
    print("Exercitiul 36")
    complete_urls(BASE_URL, ["/about", "contact.html", "../index.html"])

    # Testul cunoscut este facut inainte de cererea catre site.
    print("Exercitiul 39 - test")
    test_images()

    try:
        response = fetch(BASE_URL)
        response.raise_for_status()
        print("Exercitiul 37")
        links = extract_links(response.text)
        print(links)
        print("Exercitiul 38")
        internal, external = split_links(links, BASE_URL)
        print("Interne:", internal)
        print("Externe:", external)
        print("Exercitiul 39 - site")
        find_images(response.text)
    except requests.RequestException as error:
        print("Exercitiile 37-39: pagina nu este disponibila:", error)

    print("Exercitiul 40")
    try:
        first = page_fingerprint(BASE_URL)
        second = page_fingerprint(BASE_URL)
        print(first)
        print(second)
        print("Amprente egale:", first == second)
    except requests.RequestException as error:
        print("Nu pot calcula amprenta paginii:", error)
    # Amprentele difera daca se schimba cel putin un octet al paginii,
    # de exemplu continutul sau o valoare generata la fiecare cerere.

    print("Exercitiul 41")
    try:
        save_headers(BASE_URL)
    except requests.RequestException as error:
        print("Nu pot citi antetele:", error)

    print("Exercitiul 42")
    try:
        print("IP:", resolve("cybercor.org"))
    except socket.gaierror as error:
        print("Nu pot afla IP-ul:", error)

    print("Exercitiul 43")
    try:
        print("Zile pana la expirare:", cert_days_left("cybercor.org"))
    except (OSError, ValueError, KeyError) as error:
        print("Nu pot citi certificatul:", error)


if __name__ == "__main__":
    run()
