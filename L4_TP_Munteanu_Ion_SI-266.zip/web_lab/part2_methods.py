# Laborator: functii, metode si importuri pe web
# Student: Munteanu Ion
# Grupa: SI-266

import requests
import time

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10


def run():
    """Executa exercitiile 9-20."""
    try:
        response = requests.get(BASE_URL, timeout=TIMEOUT)
    except requests.RequestException as error:
        print("Nu pot descarca pagina:", error)
        return

    print("Exercitiul 9")
    print(response.status_code)  # atribut
    print(response.ok)           # atribut
    print(response.url)          # atribut
    print(response.encoding)     # atribut

    print("Exercitiul 10")
    try:
        response.raise_for_status()  # metoda
        print("Pagina principala este disponibila.")
    except requests.HTTPError:
        print("Pagina principala a raspuns cu o eroare HTTP.")
    time.sleep(1)
    try:
        missing = requests.get(BASE_URL + "/this-page-does-not-exist", timeout=TIMEOUT)
        missing.raise_for_status()
        print("Adresa de test a raspuns cu:", missing.status_code)
    except requests.HTTPError as error:
        print("Pagina de test nu este disponibila. Cod:", error.response.status_code)
    except requests.RequestException as error:
        print("Nu pot verifica pagina de test:", error)

    print("Exercitiul 11")
    for name, value in response.headers.items():
        print(name + ": " + value)

    print("Exercitiul 12")
    print("Server:", response.headers.get("Server", "lipseste"))
    print("Content-Type:", response.headers.get("Content-Type", "lipseste"))
    print("content-type:", response.headers.get("content-type", "lipseste"))
    # Antetele nu fac diferenta intre litere mari si mici.

    print("Exercitiul 13")
    print("Aparitii cyber:", response.text.lower().count("cyber"))
    # lower returneaza tot un sir, pe care pot apela count.

    print("Exercitiul 14")
    html = response.text
    start = html.lower().find("<title>")
    if start != -1:
        start += len("<title>")
        end = html.lower().find("</title>", start)
        if end != -1:
            print("Titlu:", html[start:end].strip())
        else:
            print("Titlul nu are tag de inchidere.")
    else:
        print("Titlu lipsa")

    print("Exercitiul 15")
    lines = html.splitlines()
    print("Numar de linii:", len(lines))
    print("Lungimea maxima:", len(max(lines, key=len)) if lines else 0)

    print("Exercitiul 16")
    if response.url.startswith("https://"):
        print("Conexiune securizata")
    else:
        print("Conexiune nesecurizata")

    print("Exercitiul 17")
    time.sleep(1)
    try:
        redirected = requests.get("http://cybercor.org", timeout=TIMEOUT)
        for step in redirected.history:
            print(step.status_code, step.url)
        print("URL final:", redirected.url)
        print("Cod final:", redirected.status_code)
        if not redirected.history:
            print("Nu au fost primite redirectionari.")
    except requests.RequestException as error:
        print("Nu pot verifica redirectionarile:", error)

    print("Exercitiul 18")
    time.sleep(1)
    try:
        head_response = requests.head(BASE_URL, timeout=TIMEOUT)
        time.sleep(1)
        get_response = requests.get(BASE_URL, timeout=TIMEOUT)
        print("HEAD:", len(head_response.content), "octeti")
        print("GET:", len(get_response.content), "octeti")
    except requests.RequestException as error:
        print("Nu pot compara cererile:", error)
    # HEAD cere doar antetele. GET primeste si corpul raspunsului.

    print("Exercitiul 19")
    if response.cookies:
        for cookie in response.cookies:
            print(cookie.name, cookie.secure)
    else:
        print("Niciun cookie setat")

    print("Exercitiul 20")
    time.sleep(1)
    try:
        with requests.Session() as session:
            agent = "WebLab-Munteanu-Ion"
            session.headers.update({"User-Agent": agent})
            echo = session.get(ECHO_URL + "/headers", timeout=TIMEOUT)
            echo.raise_for_status()
            sent = echo.json()["headers"].get("User-Agent")
            print("User-Agent primit:", sent)
            print("Antet confirmat:", sent == agent)
    except (requests.RequestException, ValueError, KeyError) as error:
        print("Nu pot verifica antetul:", error)

    # text este atribut. json() este metoda care transforma corpul
    # JSON intr-un obiect Python si trebuie apelata cu paranteze.
    if not response.ok:
        print("Observatie: analiza HTML a folosit corpul raspunsului de eroare.")


if __name__ == "__main__":
    run()
