# Laborator: functii, metode si importuri pe web
# Student: Munteanu Ion
# Grupa: SI-266

import argparse
import csv
from datetime import datetime
from urllib.parse import urlparse
import requests
import webtools
from webtools import get_title, security_headers, DEFAULT_HEADERS

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10

# Exercitiul 45: o functie get_title definita dupa import ar inlocui
# numele importat. webtools.get_title ar ramane functia din modul.


def main():
    """Citeste URL-ul si creeaza rapoartele CSV si JSON."""
    # Exercitiul 48
    parser = argparse.ArgumentParser(description="Laborator 4 TP - Munteanu Ion")
    parser.add_argument("url", nargs="?", default=BASE_URL)
    args = parser.parse_args()
    if urlparse(args.url).scheme not in ("http", "https") or not urlparse(args.url).hostname:
        parser.error("Scrie un URL complet, de exemplu https://cybercor.org")

    # Exercitiul 47
    print("Student: Munteanu Ion, SI-266")
    print("Antete implicite:", DEFAULT_HEADERS)

    # Exercitiile 44 si 45
    try:
        print("Titlu prin modul:", webtools.get_title(webtools.fetch(args.url).text))
        print("Titlu prin import direct:", get_title("<title>Laborator 4</title>"))
        print("Antete de securitate:", security_headers(args.url))
    except requests.RequestException as error:
        print("Pagina nu este disponibila:", error)

    # Exercitiul 49
    results = webtools.check_paths(args.url, ["/", "/robots.txt", "/sitemap.xml"])
    with open("report.csv", "w", newline="", encoding="utf-8") as file:
        writer = csv.writer(file)
        writer.writerow(["path", "status", "checked_at"])
        for path, status in results.items():
            writer.writerow([path, status, datetime.now().isoformat()])
    print("Salvat in report.csv")

    # Exercitiul 50
    webtools.site_report(args.url)


if __name__ == "__main__":
    main()
